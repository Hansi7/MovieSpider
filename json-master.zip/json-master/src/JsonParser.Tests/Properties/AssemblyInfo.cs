﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyTitle("")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("JsonParser")]
[assembly: AssemblyCopyright("Public Domain")]
[assembly: AssemblyTrademark("Public Domain")]
[assembly: AssemblyCulture("")]
[assembly: Guid("5127215b-9fbf-4de9-b21a-d8c8debf8211")]