﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("JSON Parser")]
[assembly: AssemblyDescription("A parser for the JSON specification")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("JsonParser")]
[assembly: AssemblyCopyright("Public Domain")]
[assembly: AssemblyTrademark("Public Domain")]
[assembly: AssemblyCulture("")]
[assembly: Guid("486c87de-5529-47da-a31f-eae00e762c84")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: InternalsVisibleTo("JsonParser.Tests, PublicKey=00240000048000009400000006020000002400005253413100040000010001004fea304b19e53fc41c78655515ad3aeaf8df257887ba75d34b0c52f050ec64534f59ad2b2fb609f233fb65561cf2cdcaef899d6c7410233896b6226ff9595cba09c4ac7e53fd029bbbf6ddee67e6acddeb12492ebfe5900e7d0599cc4f9bf99fcb00a0361dd642b7d6d31d4a7ffec74cf8654adba57ab29c38702d3b76b1e0b0")]
