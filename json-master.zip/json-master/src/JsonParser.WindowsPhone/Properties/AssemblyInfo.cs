﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("JSON Parser")]
[assembly: AssemblyDescription("A parser for the JSON specification.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("JsonParser")]
[assembly: AssemblyCopyright("Public Domain")]
[assembly: AssemblyTrademark("Public Domain")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("ba51da4f-8fda-4909-a75e-0e25a56b30d2")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
