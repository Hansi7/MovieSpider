﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Dimebrain JSON Parser")]
[assembly: AssemblyDescription("A parser for the JSON specification.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Dimebrain")]
[assembly: AssemblyProduct("JsonParser")]
[assembly: AssemblyCopyright("Public Domain")]
[assembly: AssemblyTrademark("Public Domain")]
[assembly: AssemblyCulture("")]
[assembly: Guid("c44e53d4-fed5-470a-bb08-bd901c984de3")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: InternalsVisibleTo("JsonParser.Tests")]

