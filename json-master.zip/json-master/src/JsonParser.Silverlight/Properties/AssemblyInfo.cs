﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("JSON Parser")]
[assembly: AssemblyDescription("A parser for the JSON specification.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("JsonParser")]
[assembly: AssemblyCopyright("Public Domain")]
[assembly: AssemblyTrademark("Public Domain")]
[assembly: AssemblyCulture("")]
[assembly: Guid("ea9301b8-29c6-4933-9109-cc7d5eebe9f5")]
[assembly: AssemblyVersion("1.0.0.0")]
